Feature('Contact Us Page');

Scenario('Can be opened and fill the information', ({ I }) => {
     I.amOnPage ("/");
     I.click (".hbspt-forms-0.1:$0.1:$your_name.$your_name.0");
     //I.switchTo();
     I.fillField("Zandile Dlamini");
     I.click(".hbspt-forms-0.1:$1.1:$mobilephone.$mobilephone.0");
     I.fillField("0616937430");
     //I.doubleclick();
    // I.switchTo();
     I.click(".hbspt-forms-0.1:$0.1:$email.$email.0");
     //I.switchTo();
     //I.click();
     I.fillField("Zandiledlamini991112@gmail.com");
     I.seeCheckboxIsChecked(".hbspt-forms-0.2.0.1:0.$LEGAL_CONSENT=1subscription_type_10841063.$LEGAL_CONSENT=1subscription_type_10841063.$LEGAL_CONSENT=1subscription_type_10841063.0.0.0.0");
     I.saveScreenshot(Zandile_test.png);

});
